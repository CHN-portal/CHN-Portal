Sample configuration files for:

SystemD: cbdhealthnetworkd.service
Upstart: cbdhealthnetworkd.conf
OpenRC:  cbdhealthnetworkd.openrc
         cbdhealthnetworkd.openrcconf
CentOS:  cbdhealthnetworkd.init
OS X:    org.cbdhealthnetwork.cbdhealthnetworkd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
